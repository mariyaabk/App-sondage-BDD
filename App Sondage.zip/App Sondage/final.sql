Drop TABLE IF EXISTS Statistique;
DROP TABLE IF EXISTS Reponse ;
DROP TABLE IF EXISTS Question;
DROP TABLE IF EXISTS Sondage ;
Drop Table IF EXISTS Compte_repondeur ;
Drop Table IF EXISTS Compte_sondeur;
Drop Table IF EXISTS Compte;

CREATE TABLE "Compte" (
     Id_compte Int,
	constraint Pk_Compte PRIMARY KEY(id_compte)	
);

CREATE TABLE "Compte_sondeur" (
        Id_compte Int,
        Nom VARCHAR(20),
        Prenom VARCHAR(20),
        Sexe VARCHAR(20),
        Date_naissance Date,
        Pays VARCHAR(20),
        Ville VARCHAR(20),
        Societe Varchar(20),
        Raison_social VARCHAR(20),
        Email varchar(20),
        Mdp Varchar(20),
	constraint Pk_Compte_sondeur PRIMARY KEY(id_compte)
) INHERITS ("Compte");

CREATE TABLE "Compte_repondeur" (
        Id_compte Int,
        Sexe VARCHAR(20),
        Date_naissance Date,
        Pays VARCHAR(20),
        Ville VARCHAR(20),
	    Lien_sondage VARCHAR(20),
        Constraint PK_Compte_repondeur
             Primary key(Id_compte)
) INHERITS ("Compte") ;


create table "Sondage" (
	Id_sondage int,
	Id_sondeur int,
	Theme varchar(20),
	Description varchar(20),
	Lien_sondage VARCHAR(20),
	constraint Pk_Sondage PRIMARY KEY(id_sondage)
	);
	
		
create table "Question"(
	Id_Question int,
	Id_Sondage int,
	Intitule varchar(20),
		constraint Pk_Question PRIMARY KEY(id_question)
);



Create TABLE "Reponse"(
	    id_question Int,
        Id_reponse Int,
        Id_repondeur Int,
        Intitule VARCHAR(20),
        Constraint Pk_Reponse 
              Primary key(Id_reponse)
);

Create Table "Statistique"(
        Id_statistique Int,
        Id_question Int,
        Id_reponse Int,
        Constraint Pk_Statistique
              Primary key(Id_statistique)
);        

-- CREATION DES REFERENCES DE TABLE
ALTER TABLE "Sondage" ADD 
		Constraint Fk_Sondage Foreign key(Id_sondeur)
               References "Compte_sondeur"(Id_compte);
			   
ALTER TABLE "Question" ADD
        Constraint Fk_Question Foreign key(Id_sondage)
               References "Sondage"(Id_sondage);
			   
ALTER TABLE "Reponse" ADD
          Constraint Fk_Reponse Foreign key(Id_repondeur)
              References "Compte_repondeur"(id_compte);

ALTER TABLE "Statistique" ADD 
           Constraint Fk_Statistique Foreign key(Id_question)
              References "Question"(id_question);
			 
ALTER TABLE "Statistique" ADD
           Constraint Fk_Statistique_Reponse Foreign key(Id_reponse)
              References "Reponse"(Id_reponse);
			 
ALTER TABLE "Reponse" ADD 
          Constraint FK_Reponse_Question Foreign key (Id_question)
			  References "Question"(id_question);

--les insertions pour chaque table 
--Table Compte 
INSERT INTO "Compte"(id_compte)
VALUES (2),
(5);

--Table Compte_Sondeur 
INSERT INTO "Compte_sondeur"(id_compte,Nom,Prenom,Sexe,Date_naissance,Pays,Ville,Societe,Raison_social,Email,Mdp)
VALUES (2,'Jean','Couvreur','Masculin',TO_DATE('02/01/1996', 'DD/MM/YYYY'),'France','Orléans','CreaCosm','Cosmètique','JeanMichel@gmail.com','AAAA'),
(5,'Rania','Motawakil','Feminin',TO_DATE('09/05/2000', 'DD/MM/YYYY'),'Maroc','Tanger','Azura','Textile','M.Rania@gmail.com','BBBB');

--Table Compte_Repondeur
INSERT INTO "Compte_repondeur"(id_compte,Lien_sondage,Sexe,Date_naissance,Pays,Ville)
VALUES (6,'www.monsondage.fr','Masculin',TO_DATE('02/01/2001', 'DD/MM/YYYY'),'France','La Defense'),
(8,'www.sondageAzura.fr','Feminin',TO_DATE('10/07/1995', 'DD/MM/YYYY'),'Maroc','Agadir');


--Table Sondage

INSERT INTO "Sondage"(id_sondage,Lien_sondage,Id_Sondeur,Theme,Description)
VALUES (10,'www.monsondage.fr',5,'Cosmetique','produits cosmetique'),
(8,'www.sondageAzura.fr',2,'Textile','produits textile');

--Table Question

INSERT INTO "Question"(id_question,Id_Sondage,Intitule)
VALUES (11,10,'Questions sondage 1'), (12,8,'Questions sondage 5');


--Table Reponse

INSERT INTO "Reponse"(id_reponse,Id_question,Id_repondeur,Intitule)
VALUES (11,11,6,'Reponse sondage 1'),
 (12,12,8,'Reponse sondage 5');

--Table Statistique

INSERT INTO "Statistique"(id_statistique,Id_question,Id_reponse)
VALUES (15,11,11),
(20,12,12);



