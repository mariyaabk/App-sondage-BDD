--tester la création de nos tables , les attributs , les colonnes et les types 
Select distinct * from "Compte";
Select distinct * from "Compte_repondeur";
Select distinct * from "Compte_sondeur";
Select distinct * from "Question";
Select distinct * from "Reponse";
Select distinct * from "Sondage";
Select distinct * from "Statistique";

--Pour l'affichage de nos resultats selon un criteres bien donné:
--par exemple on veut afficher les donnees des utilisateurs (deja inscrits) dans le maroc et la france :
Select * from "Compte_sondeur" where pays='Maroc';
Select * from "Compte_sondeur" where pays='France';

--la meme chose , si on veut afficher les donnees des gens qui vont repondre 
    --par PAYS :
Select Pays"Maroc",count(*) from "Compte_repondeur" GROUP BY Pays;
    --en decendant dans l'arborescence , par ville
Select pays"Maroc",ville"Agadir",count(*) from "Compte_repondeur" group by Pays,ville;

--Si on veut par exemple organiser les donnees des utilisateurs soit du compte_repondeur ou du compte_sondeur selon la date de naissance 
Select * From "Compte_sondeur" order by date_naissance ASC;
Select * From "Compte_sondeur" order by date_naissance DESC;
    -- on utilise les mots cles ASC et DESC pour trier par odre croissant ou par ordre decroissant 
--meme chose pour compte repondeur 
Select * FROM "Compte_repondeur" order by date_naissance ASC;
Select * FROM "Compte_repondeur" order by date_naissance DESC;


--Utilisation des curseurs 
--Pour la selection et l'affichage des donnees de plusieurs table a l'aide d'un curseur 
   -- exemple de table compte sondeur et compte repindeur
Declare
X cursor FOR select * from "Compte_sondeur",
CX  "Compte_sondeur".nom % type,
CY "Reponse".prenom%type;
begin
for c_rec in c 
loop
Select nom into CX from "Compte_sondeur" where id_compte=c_rec.id_compte;
select intitule into CY from "Reponse" where id_reponse=c_reponse.id_reponse;
dbms_output.put_line('les noms des sondeurs sont :'||CX);
dbms_output.put_line('les prenoms des sondeurs sont :'||CY);
END;

--caclul des sondages durant une periode donnee
DECLARE 
x int;
Begin 
Select count(id_sondage)into x where date='10-10-2022'-date.dual;
dbms_output.put_line(''||x);
end;
/

--pour pouvoir visualiser les reponses du sondages pour:

--un compte repondeur precis ayant un id egal a x:
select * from "Reponse" Inner join "Compte_repondeur" On 
"Reponse".id_reponse="Compte_repondeur".id_compte;
--NB: pour pouvoir visualer toutes les reponses pour un compte repondeur ou bien 
-- pour pouboir visualiser toutes les questions pour un compte sondeur
-- on a besoin de curseur 
-- cest pour cela que nos exemples sont par rapport aux comptes precis 

--meme chose pour pouvoir visualiser les questions 
--pour un compte precis
select * from "Question" inner join "Sondage" 
 On  "Question".Id_sondage="Sondage".id_sondeur
 inner join "Compte_sondeur"
 On "Compte_sondeur".Id_compte="Sondage".id_sondeur;

--pour enfin pouvoir visualiser les statistiques 
select* from "Statistique" ; 

--pour Statistique de chaque question et sa reponse
select * from "Statistique" inner join "Reponse" On
"Reponse".id_reponse="Statistique".id_reponse
inner join "Question"
On "Question".id_question="Statistique".id_question ;

Select Id_question,count(Id_reponse) From "Reponse"
GROUP BY Id_question;

Select Pays,count(Id_repondeur) FROM "Compte_repondeur" inner Join "Reponse"
 ON "Compte_repondeur".Id_Compte="Reponse".Id_repondeur
 GROUP BY Pays;

Select Sexe,count(Id_repondeur) FROM "Compte_repondeur" inner Join "Reponse"
ON "Compte_repondeur".Id_Compte="Reponse".Id_repondeur
 GROUP BY Sexe;